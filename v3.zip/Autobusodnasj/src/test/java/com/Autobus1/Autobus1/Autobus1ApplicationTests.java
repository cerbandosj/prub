package com.Autobus1.Autobus1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Autobus1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
