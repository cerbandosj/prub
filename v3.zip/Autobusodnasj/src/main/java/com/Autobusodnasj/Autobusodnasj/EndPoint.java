package com.Autobusodnasj.Autobusodnasj;
import org.example.autobusodnasj.AgregarBoletoRequest;
import org.example.autobusodnasj.AgregarBoletoResponse;
import org.example.autobusodnasj.AgregarClienteRequest;
import org.example.autobusodnasj.AgregarClienteResponse;
import org.example.autobusodnasj.AgregarRutaRequest;
import org.example.autobusodnasj.AgregarRutaResponse;
import org.example.autobusodnasj.AgregarViajeRequest;
import org.example.autobusodnasj.AgregarViajeResponse;
import org.example.autobusodnasj.CancelarBoletoRequest;
import org.example.autobusodnasj.CancelarBoletoResponse;
import org.example.autobusodnasj.ConsultarBoletoRequest;
import org.example.autobusodnasj.ConsultarBoletoResponse;
import org.example.autobusodnasj.ConsultarClienteRequest;
import org.example.autobusodnasj.ConsultarClienteResponse;
import org.example.autobusodnasj.ConsultarRutaRequest;
import org.example.autobusodnasj.ConsultarRutaResponse;
import org.example.autobusodnasj.ConsultarViajeRequest;
import org.example.autobusodnasj.ConsultarViajeResponse;
import org.example.autobusodnasj.EliminarClienteRequest;
import org.example.autobusodnasj.EliminarClienteResponse;
import org.example.autobusodnasj.EliminarRutaRequest;
import org.example.autobusodnasj.EliminarRutaResponse;
import org.example.autobusodnasj.EliminarViajeRequest;
import org.example.autobusodnasj.EliminarViajeResponse;
import org.example.autobusodnasj.ModificarClienteRequest;
import org.example.autobusodnasj.ModificarClienteResponse;
import org.example.autobusodnasj.ModificarRutaRequest;
import org.example.autobusodnasj.ModificarRutaResponse;
import org.example.autobusodnasj.ModificarViajeRequest;
import org.example.autobusodnasj.ModificarViajeResponse;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import controlador.BoletoDAO;
import controlador.ClienteDAO;
import controlador.RutaDAO;
import controlador.ViajeDAO;
/*
import controlador.BoletoDAO;
import controlador.RutaDAO;
*/
import modelo.Ruta;
import modelo.Viaje;
import modelo.Boleto;
import modelo.Cliente;




@Endpoint
public class EndPoint {
	
	
 	@PayloadRoot(namespace = "http://www.example.org/Autobusodnasj",localPart = "AgregarRutaRequest")

@ResponsePayload
public AgregarRutaResponse  getAgregarRuta( @RequestPayload  AgregarRutaRequest  peticion ) {
	AgregarRutaResponse respuesta = new  AgregarRutaResponse ();
	RutaDAO Ruta =  new  RutaDAO ( peticion . getIdRuta(), peticion . getNombreRuta(),peticion .getDestino(),peticion .getFechaSalida(), 
			peticion.getHora(), peticion .getCosto() , peticion .getNumAsiento());
	if(Ruta.AgregarRuta()){
		respuesta . setRespuesta ( " Se  agrego con exito la ruta al sistema " + Ruta.getNombreRuta() +"" );
	} else {
		respuesta . setRespuesta ( " No se ha añadido la ruta   al sistema "  + Ruta.getNombreRuta()
		+ "");
	}
	return respuesta;
	
	}
 
	
	
	
	
	
	
	@PayloadRoot(namespace = "http://www.example.org/Autobusodnasj",localPart = "ConsultarRutaRequest")

	@ResponsePayload
	public ConsultarRutaResponse  getConsultarRuta ( @RequestPayload  ConsultarRutaRequest  peticion ) {
		ConsultarRutaResponse respuesta = new  ConsultarRutaResponse ();
		RutaDAO ruta =  new  RutaDAO ( peticion . getIdRuta ());
		
		Ruta r = ruta.ConsultarIdRuta();
		if(r != null){
			respuesta.setIdRuta (r.getIdRuta());  	
			respuesta.setNombreRuta(r.getNombreRuta());
			respuesta.setDestino(r.getDestino());
			respuesta.setFechaSalida( r.getFechaSalida());
			respuesta.setHora( r.getHora());
			respuesta.setCosto( r.getCosto());
			respuesta.setNumAsiento( r.getNumAsiento());
			
		} else {
			respuesta. setNombreRuta ( " No se pudo consultar la ruta intente mas tarde " );
		}
		return respuesta;
	}
	
		
	@PayloadRoot(namespace = "http://www.example.org/Autobusodnasj",localPart = "EliminarRutaRequest")

	@ResponsePayload
	public EliminarRutaResponse  getEliminarRuta ( @RequestPayload  EliminarRutaRequest  peticion ) {
		EliminarRutaResponse respuesta = new  EliminarRutaResponse ();
		RutaDAO Ruta =  new  RutaDAO ( peticion . getIdRuta ());
		if(Ruta.EliminarRuta()){
			respuesta.setRespuesta ( " Se elimino la ruta  del sistema" );
		} else {
			respuesta.setRespuesta ( " No se puedo eliminar la ruta del sistema " );
		}
		return respuesta;
	}
	
		


	@PayloadRoot(namespace = "http://www.example.org/Autobusodnasj",localPart = "ModificarRutaRequest")
	@ResponsePayload
	public ModificarRutaResponse getModificarRuta(@RequestPayload ModificarRutaRequest peticion) {
		ModificarRutaResponse respuesta = new ModificarRutaResponse();
		RutaDAO ruta= new RutaDAO(peticion . getIdRuta(), peticion . getNombreRuta(),peticion .getDestino(),peticion .getFechaSalida(), 
				peticion.getHora(), peticion .getCosto() , peticion .getNumAsiento());
		if (ruta.verificarIdRuta()) {
			if (ruta.ModificarRuta()) {
				respuesta.setIdRuta("Se ha actualizado la ruta"+ruta.getIdRuta()+ " " + ruta.getNombreRuta() + " en el sistema");
			} else {
				respuesta.setIdRuta("No se ha podido actualizar la Ruta ");
				}
		
		
	}
	
		return respuesta;
	}
	
		
	
	
	 	@PayloadRoot(namespace = "http://www.example.org/Autobusodnasj",localPart = "AgregarClienteRequest")

	@ResponsePayload
	public AgregarClienteResponse  getAgregarCliente ( @RequestPayload  AgregarClienteRequest  peticion ) {
		AgregarClienteResponse respuesta = new  AgregarClienteResponse ();
		ClienteDAO Cliente =  new  ClienteDAO ( peticion . getNombreCliente (), peticion . getApellidos(), peticion . getIdCliente());
		if(Cliente.AgregarCliente()){
			respuesta . setRespuesta ( " Se ha agregado el cliente  " + Cliente.getNombreCliente() + " " + Cliente.getApellidos()
			+ "");
		} else {
			respuesta . setRespuesta ( " No se ha añadido el cliente  al sistema " + Cliente.getNombreCliente() + "" + Cliente.getApellidos()
			+ "");
		}
		return respuesta;
		
		}
	 
		 	
	 	
		@PayloadRoot(namespace = "http://www.example.org/Autobusodnasj",localPart = "ConsultarClienteRequest")

		@ResponsePayload
		public ConsultarClienteResponse  getConsultarCliente ( @RequestPayload  ConsultarClienteRequest  peticion ) {
			ConsultarClienteResponse respuesta = new  ConsultarClienteResponse ();
			ClienteDAO cliente =  new  ClienteDAO ( peticion . getIdCliente ());
			
			Cliente c = cliente.ConsultarCliente();
			
			if(c != null){
				respuesta.setIdCliente (c.getIdCliente());  	
				respuesta.setNombreCliente(c.getNombreCliente());
				respuesta.setApellidos(c.getApellidos());
			} else {
				respuesta. setNombreCliente ( " No se pudo consultar Cliente intente mas tarde " );
			}
			return respuesta;
		}
	 
	 	
	 	
		
	 	 	@PayloadRoot(namespace = "http://www.example.org/Autobusodnasj",localPart = "ModificarClienteRequest")

	@ResponsePayload
	public ModificarClienteResponse  getModificarCliente( @RequestPayload  ModificarClienteRequest  peticion ) {
		ModificarClienteResponse respuesta = new  ModificarClienteResponse ();
		ClienteDAO Cliente =  new  ClienteDAO ( peticion . getNombreCliente (), peticion . getApellidos(), peticion . getIdCliente());
		
			if(Cliente.modificarCliente()) {
			 respuesta.setRespuesta( " Se a modificado el cliente " );
		} else {
			 respuesta.setRespuesta( " No se pudo modificar el cliente intente de nuevo  " );
		}
		
	
		return  respuesta;
		
		}
	 	 	
	 	 	

	 	 	
	
	
	 	 	 	@PayloadRoot(namespace = "http://www.example.org/Autobusodnasj",localPart = "EliminarClienteRequest")

	@ResponsePayload
	public EliminarClienteResponse  getEliminarCliente( @RequestPayload  EliminarClienteRequest  peticion ) {
		EliminarClienteResponse respuesta = new  EliminarClienteResponse ();
		ClienteDAO Cliente =  new  ClienteDAO ( peticion.getIdCliente());
		if(Cliente.eliminarCliente()){
			respuesta.setRespuesta( " Se ha eliminado el cliente del sistema " );
		} else {
			respuesta.setRespuesta ( " No se pudo eliminar  el cliente del  sistema " );
		}
		return respuesta;
		
		}
	 
		
	
	 	@PayloadRoot(namespace = "http://www.example.org/Autobusodnasj",localPart = "AgregarBoletoRequest")

	@ResponsePayload
	public AgregarBoletoResponse  getAgregarBoleto ( @RequestPayload  AgregarBoletoRequest  peticion ) {
		AgregarBoletoResponse respuesta = new  AgregarBoletoResponse ();
		BoletoDAO Boleto =  new  BoletoDAO ( peticion . getId () ,
				peticion.getDestino(),peticion.getFechaSalida(),peticion.getHora(),peticion.getNombreCliente(),
				peticion.getTipoBoleto(),peticion.getCosto(),peticion.getNumAsiento());
		if(Boleto.AgregarBoleto()){
			respuesta . setRespuesta ( " Se ha agregado el boleto al sistema ");
		} else {
			respuesta . setRespuesta ( " No se ha añadio el boleto   al sistema ");
		}
		return respuesta;
		
		}
	 	
	 	
	
	 
		 	
	 	
	 	
	 	@PayloadRoot(namespace = "http://www.example.org/Autobusodnasj",localPart = "ConsultarBoletoRequest")

		@ResponsePayload
		public ConsultarBoletoResponse  getConsultarBoleto ( @RequestPayload  ConsultarBoletoRequest  peticion ) {
			ConsultarBoletoResponse respuesta = new  ConsultarBoletoResponse ();
			BoletoDAO boleto =  new  BoletoDAO ( peticion . getId ());
			
			Boleto b = boleto.ConsultarBoleto();
			
			if(b != null){
				respuesta.setId (b.getId());
				respuesta.setDestino(b.getDestino());
				respuesta.setFechaSalida(b.getFechaSalida());
				respuesta.setHora(b.getHora());
				respuesta.setNombreCliente(b.getNombreCliente());
				respuesta.setTipoBoleto(b.getDestino());
				respuesta.setCosto(b.getCosto());
				respuesta.setNumAsiento(b.getNumAsiento());
			
			} else {
				respuesta. setId ( " No se pudo consultar el boleto intente mas tarde " );
			}
			return respuesta;
		}
	 
	 	
	 	
	 	
	
	

	
	 	 @PayloadRoot(namespace = "http://www.example.org/Autobusodnasj",localPart = "CancelarBoletoRequest")

	@ResponsePayload
	public CancelarBoletoResponse  getCancelarBoleto( @RequestPayload CancelarBoletoRequest  peticion ) {
		CancelarBoletoResponse respuesta= new  CancelarBoletoResponse ();
		BoletoDAO Boleto =  new  BoletoDAO ( peticion . getId ());
		if(Boleto.CancelarBoleto()){
			respuesta.setRespuesta ( " Se ha cancelado el boleto"  + Boleto.getId());
		} else {
			respuesta.setRespuesta ( " No se ha podido cancelar el boleto del sistema" );
		}
		return respuesta;
	}

	 	 
	 /*	 ********************** Viajes****************************************/
	 	 
	

	  	@PayloadRoot(namespace = "http://www.example.org/Autobusodnasj",localPart = "AgregarViajeRequest")

	 @ResponsePayload
	 public AgregarViajeResponse  getAgregarViaje( @RequestPayload  AgregarViajeRequest  peticion ) {
	 	AgregarViajeResponse respuesta = new  AgregarViajeResponse ();
	 	ViajeDAO Viaje =  new  ViajeDAO ( peticion . getId(),peticion .getDestino(),peticion .getFechaSalida(), 
	 			peticion.getHora(),peticion.getNombreCliente(), peticion .getCosto() , peticion .getNumAsiento());
	 	if(Viaje.AgregarViaje()){
	 		respuesta . setRespuesta ( " Se  agrego con exito el Viaje al sistema " );
	 	} else {
	 		respuesta . setRespuesta ( " No se ha añadido el Viaje al sistema " 
	 		+ "");
	 	}
	 	return respuesta;
	 	
	 	}
	  
	 	
	 
	 	
	 	
	 	@PayloadRoot(namespace = "http://www.example.org/Autobusodnasj",localPart = "ConsultarViajeRequest")

	 	@ResponsePayload
	 	public ConsultarViajeResponse  getConsultarViaje( @RequestPayload  ConsultarViajeRequest  peticion ) {
	 		ConsultarViajeResponse respuesta = new  ConsultarViajeResponse ();
	 		ViajeDAO viaje =  new  ViajeDAO ( peticion . getId ());
	 		
	 		Viaje v = viaje.ConsultarId();
	 		if(v != null){
	 			respuesta.setId (v.getId());  	
	 		
	 			respuesta.setDestino(v.getDestino());
	 			respuesta.setFechaSalida( v.getFechaSalida());
	 			respuesta.setHora( v.getHora());
	 			respuesta.setNombreCliente( v.getNombreCliente());
	 			respuesta.setCosto( v.getCosto());
	 			respuesta.setNumAsiento( v.getNumAsiento());
	 			
	 		} else {
	 			respuesta. setId ( " No se pudo consultar el viaje intente mas tarde " );
	 		}
	 		return respuesta;
	 	}
	 	
	 
	
	 	
	 	@PayloadRoot(namespace = "http://www.example.org/Autobusodnasj",localPart = "EliminarViajeRequest")

	 	@ResponsePayload
	 	public EliminarViajeResponse  getEliminarViaje ( @RequestPayload  EliminarViajeRequest  peticion ) {
	 		EliminarViajeResponse respuesta = new  EliminarViajeResponse ();
	 		ViajeDAO  Viaje =  new  ViajeDAO ( peticion . getId ());
	 		if(Viaje.EliminarViaje()){
	 			respuesta.setRespuesta ( " Se elimino el viaje del sistema" );
	 		} else {
	 			respuesta.setRespuesta ( " No se puedo eliminar el viaje del sistema " );
	 		}
	 		return respuesta;
	 	}
	 	



	 	@PayloadRoot(namespace = "http://www.example.org/Autobusodnasj",localPart = "ModificarViajeRequest")
	 	@ResponsePayload
	 	public ModificarViajeResponse getModificarViaje(@RequestPayload ModificarViajeRequest peticion) {
	 		ModificarViajeResponse respuesta = new ModificarViajeResponse();
	 		ViajeDAO viaje = new ViajeDAO(peticion . getId(),peticion .getDestino(),peticion .getFechaSalida(), 
	 				peticion.getHora(),peticion.getNombreCliente(), peticion .getCosto() , peticion .getNumAsiento());
	 		
	 			if (viaje.ModificarViaje()) {
	 				respuesta.setRespuesta("Se ha actualizado el viaje "+viaje.getId()+  " en el sistema");
	 			} else {
	 				respuesta.setRespuesta("No se ha podido actualizar el viaje");
	 				}
	 		
	 		
	 	
	 	
	 		return respuesta;
	 	}
	 	
	 	 
	 	 
	 	 
	 	 
	 	 
	 	 
}