package controlador;



import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import modelo.Boleto;
import modelo.Ruta;
import database.conexion;
import modelo.Boleto;
import java.util.logging.Level;
import java.util.logging.Logger;

import database.conexion;


public class BoletoDAO {
	private String Id;
	private String Destino;
	private String FechaSalida;
	private String Hora;
	private String NombreCliente;
	private String TipoBoleto;
	private String Costo;
	private String NumAsiento;
	
	private conexion database;
	
	
	
	public BoletoDAO(String Id, String Destino,String FechaSalida,String Hora,String NombreCliente, String TipoBoleto,String Costo, String NumAsiento) {
		this.Id = Id;
		this.Destino = Destino;
		this.FechaSalida = FechaSalida;
		this.Hora = Hora;
		this.NombreCliente = NombreCliente;
		this.TipoBoleto = TipoBoleto;
		this.Costo = Costo;
		this.NumAsiento = NumAsiento;
		
	}
	

public BoletoDAO() throws ClassNotFoundException{
	database = new conexion();
}

	
	
	/**
	 * @param idReservacion
	 */
	public BoletoDAO(String Id) {
		this.Id = Id;
	}

	/**
	 * @return the idReservacion
	 */
	public String getId() {
		return Id;
	}

	
	/**
	 * Metodo para agregar una reservacion
	 * @return
	 */
	public boolean AgregarBoleto() {
		boolean resultado = false;
		this.database = new conexion();
		try {
			this.database.connection().createStatement().execute(
					"INSERT INTO boleto(Id,Destino,FechaSalida,Hora,NombreCliente,TipoBoleto,Costo,NumAsiento) VALUES "
					+ "('"+this.Id+"','"+this.Destino+"','"+this.FechaSalida+"','"+this.Hora+"','"+this.NombreCliente+"','"+this.TipoBoleto+"','"+this.Costo+"','"+this.NumAsiento+"')");
			resultado = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultado;


	}

	
	

	
	
	
	/**
	 * Metodo para actualizar una reservacion en la Base de Datos
	 * @return true si se actualizo la reservacion de forma exitosa en la BD
	 */
	
	
	/**
	 * @return true si se elimina la reservacion de forma exitosa
	 */
	public boolean CancelarBoleto() {
		boolean resultado = false;
		this.database = new conexion();
		try {
			this.database.connection().createStatement().execute(
					"DELETE FROM boleto WHERE Id = '"+this.Id + "'");
			resultado = true;				
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return resultado;
	}
	
	/**
	 * Metodo para obtener el precio aproximado de la estancia
	 * @return precio
	 */

	
	/**
	 * Metodo para consultar una reservacion
	 * @param id
	 * @return
	 */
	public Boleto  ConsultarBoleto() {
		Boleto boleto = null;
	
		this.database = new conexion();
			try {
				ResultSet rs = this.database.connection().createStatement().executeQuery("SELECT * FROM boleto WHERE Id= '"+this.Id + "'");
				while(rs.next()) {
					boleto = new Boleto (rs.getString("Id"), rs.getString("Destino"),rs.getString("FechaSalida"),rs.getString("Hora"),rs.getString("NombreCliente")
							,rs.getString("TipoBoleto"),rs.getString("Costo"),rs.getString("NumAsiento"));
				}
				
				
				//this.database.connect().createStatement().execute("SELECT * FROM clientes WHERE idCliente = "+this.idCliente);
								
			} catch(SQLException e) {
				e.printStackTrace();
			}
		return boleto;
	}


	
		
	


	public String getNumAsiento() {
		// TODO Auto-generated method stub
		return null;
	}


	public String getCosto() {
		// TODO Auto-generated method stub
		return null;
	}



	


	public String getDestino() {
		// TODO Auto-generated method stub
		return null;
	}


	public String getTipoBoleto() {
		// TODO Auto-generated method stub
		return null;
	}


	public String getNombreCliente() {
		// TODO Auto-generated method stub
		return null;
	}
}