//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.7 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2020.07.14 a las 12:45:13 PM CDT 
//


package org.example.autobusodnasj;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the org.example.autobusodnasj package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: org.example.autobusodnasj
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ModificarViajeResponse }
     * 
     */
    public ModificarViajeResponse createModificarViajeResponse() {
        return new ModificarViajeResponse();
    }

    /**
     * Create an instance of {@link EliminarRutaRequest }
     * 
     */
    public EliminarRutaRequest createEliminarRutaRequest() {
        return new EliminarRutaRequest();
    }

    /**
     * Create an instance of {@link ConsultarClienteRequest }
     * 
     */
    public ConsultarClienteRequest createConsultarClienteRequest() {
        return new ConsultarClienteRequest();
    }

    /**
     * Create an instance of {@link ModificarClienteResponse }
     * 
     */
    public ModificarClienteResponse createModificarClienteResponse() {
        return new ModificarClienteResponse();
    }

    /**
     * Create an instance of {@link EliminarViajeRequest }
     * 
     */
    public EliminarViajeRequest createEliminarViajeRequest() {
        return new EliminarViajeRequest();
    }

    /**
     * Create an instance of {@link ConsultarRutaResponse }
     * 
     */
    public ConsultarRutaResponse createConsultarRutaResponse() {
        return new ConsultarRutaResponse();
    }

    /**
     * Create an instance of {@link CancelarBoletoResponse }
     * 
     */
    public CancelarBoletoResponse createCancelarBoletoResponse() {
        return new CancelarBoletoResponse();
    }

    /**
     * Create an instance of {@link ConsultarBoletoResponse }
     * 
     */
    public ConsultarBoletoResponse createConsultarBoletoResponse() {
        return new ConsultarBoletoResponse();
    }

    /**
     * Create an instance of {@link AgregarViajeResponse }
     * 
     */
    public AgregarViajeResponse createAgregarViajeResponse() {
        return new AgregarViajeResponse();
    }

    /**
     * Create an instance of {@link ModificarRutaRequest }
     * 
     */
    public ModificarRutaRequest createModificarRutaRequest() {
        return new ModificarRutaRequest();
    }

    /**
     * Create an instance of {@link AgregarRutaRequest }
     * 
     */
    public AgregarRutaRequest createAgregarRutaRequest() {
        return new AgregarRutaRequest();
    }

    /**
     * Create an instance of {@link ConsultarViajeRequest }
     * 
     */
    public ConsultarViajeRequest createConsultarViajeRequest() {
        return new ConsultarViajeRequest();
    }

    /**
     * Create an instance of {@link ConsultarViajeResponse }
     * 
     */
    public ConsultarViajeResponse createConsultarViajeResponse() {
        return new ConsultarViajeResponse();
    }

    /**
     * Create an instance of {@link ConsultarClienteResponse }
     * 
     */
    public ConsultarClienteResponse createConsultarClienteResponse() {
        return new ConsultarClienteResponse();
    }

    /**
     * Create an instance of {@link AgregarClienteRequest }
     * 
     */
    public AgregarClienteRequest createAgregarClienteRequest() {
        return new AgregarClienteRequest();
    }

    /**
     * Create an instance of {@link EliminarClienteResponse }
     * 
     */
    public EliminarClienteResponse createEliminarClienteResponse() {
        return new EliminarClienteResponse();
    }

    /**
     * Create an instance of {@link ModificarClienteRequest }
     * 
     */
    public ModificarClienteRequest createModificarClienteRequest() {
        return new ModificarClienteRequest();
    }

    /**
     * Create an instance of {@link CancelarBoletoRequest }
     * 
     */
    public CancelarBoletoRequest createCancelarBoletoRequest() {
        return new CancelarBoletoRequest();
    }

    /**
     * Create an instance of {@link ConsultarRutaRequest }
     * 
     */
    public ConsultarRutaRequest createConsultarRutaRequest() {
        return new ConsultarRutaRequest();
    }

    /**
     * Create an instance of {@link AgregarClienteResponse }
     * 
     */
    public AgregarClienteResponse createAgregarClienteResponse() {
        return new AgregarClienteResponse();
    }

    /**
     * Create an instance of {@link AgregarBoletoResponse }
     * 
     */
    public AgregarBoletoResponse createAgregarBoletoResponse() {
        return new AgregarBoletoResponse();
    }

    /**
     * Create an instance of {@link ModificarViajeRequest }
     * 
     */
    public ModificarViajeRequest createModificarViajeRequest() {
        return new ModificarViajeRequest();
    }

    /**
     * Create an instance of {@link EliminarRutaResponse }
     * 
     */
    public EliminarRutaResponse createEliminarRutaResponse() {
        return new EliminarRutaResponse();
    }

    /**
     * Create an instance of {@link AgregarBoletoRequest }
     * 
     */
    public AgregarBoletoRequest createAgregarBoletoRequest() {
        return new AgregarBoletoRequest();
    }

    /**
     * Create an instance of {@link EliminarViajeResponse }
     * 
     */
    public EliminarViajeResponse createEliminarViajeResponse() {
        return new EliminarViajeResponse();
    }

    /**
     * Create an instance of {@link AgregarRutaResponse }
     * 
     */
    public AgregarRutaResponse createAgregarRutaResponse() {
        return new AgregarRutaResponse();
    }

    /**
     * Create an instance of {@link EliminarClienteRequest }
     * 
     */
    public EliminarClienteRequest createEliminarClienteRequest() {
        return new EliminarClienteRequest();
    }

    /**
     * Create an instance of {@link AgregarViajeRequest }
     * 
     */
    public AgregarViajeRequest createAgregarViajeRequest() {
        return new AgregarViajeRequest();
    }

    /**
     * Create an instance of {@link ConsultarBoletoRequest }
     * 
     */
    public ConsultarBoletoRequest createConsultarBoletoRequest() {
        return new ConsultarBoletoRequest();
    }

    /**
     * Create an instance of {@link ModificarRutaResponse }
     * 
     */
    public ModificarRutaResponse createModificarRutaResponse() {
        return new ModificarRutaResponse();
    }

}
